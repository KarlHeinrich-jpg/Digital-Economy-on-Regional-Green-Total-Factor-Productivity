function [Max_Value,Min_Value,T,X] = N_density(begin_year,xx,yy,zz,X)
%UNTITLED 此处显示有关此函数的摘要
[N,T] = size(X);

Year_0 = begin_year; % 起始年份，需要根据原始数据的实际起始年份修改。
Year_1 = Year_0+T-1;

%% 计算各年份的核密度估计值并作图。
figure(1)

for i = 1:T
     f(:,i) = ksdensity(X(:,i));
     plot(f)
     hold on
end

j = 0;
for i = Year_0:Year_1
      j = j+1;
      str{j} = char([num2str(i),'年']);
end

legend(str)

f = f';

%% 确定三维核密度估计图的X轴和Y轴刻度。

Min_Value = min(min(X));
Max_Value = max(max(X));

M = length(f);

x = linspace(Min_Value,Max_Value,M);

y = Year_0:Year_1;

[x,y] = meshgrid(x,y); 

%% 三维核密度估计结果作图
figure(2) % 该图可以手动三维旋转。
mesh(x,y,f)
xlabel(xx);
ylabel(yy);
zlabel(zz);


end

