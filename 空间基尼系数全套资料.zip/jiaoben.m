
%% 代码已经封装好，修改部分参数即可
% 名称：面板数据的Dagum空间基尼系数计算及贡献分解。
% 数据格式需要严格按测试数据整理。
% 本代码基于MATLAB R2021a软件编写。

clc
clear all

%% 仅仅此部分需要更改！！！！！！
cd('D:\matlab2021\bin\录制视频用\空间基尼系数'); %代码及数据存放位置，需根据需要修改。 
Data = xlsread('测试数据.xlsx'); % excel文件名需按实际名称修改。


N = 30 ; % 截面数，需要根据实际数据修改。
T = 5 ;  % 时期数，需要根据实际数据修改。
num_group = 4 ; %填写分组个数
begin_year = 2016; % 起始年份，需要根据原始数据的实际起始年份修改。 



%% 无需更改！！！！！！！！
[Gini_Total,Gini_W,Gini_nb,Gini_t,G_sub,G_jh,Table_Ginis] = taier11(Data,N,T,num_group,begin_year);
