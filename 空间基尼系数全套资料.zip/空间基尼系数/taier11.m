function [Gini_Total,Gini_W,Gini_nb,Gini_t,G_sub,G_jh,Table_Ginis] = taier11(Data,N,T,num_group,begin_year)


xx = 3;  
group = 4; %分组所在列
%% 对需要进行空间基尼系数分析的数据进行格式转化
[hh,HH] = Variable_Trans_Std(Data(:,xx),N,T);  
% 空间基尼系数的分析指标，需要根据原始数据所在列数修改上一行的“4”。


%% 确定地区分类
Type_Column = group ; % 类型标志，需要根据原始数据类型标志的实际放置列数修改。 
Type = Data(1:N,Type_Column);
Num_of_Type = max(Type)-min(Type)+1;


%%

for i = 1:num_group
    var_name = sprintf('Num%d', i);  
    eval(sprintf('%s = rand(10, 1);', var_name));  
end

% 将所有变量名字符串拼接成一个字符串
var_names = '';
for i = 1:num_group
    var_names = strcat(var_names, sprintf('Num%d, ', i));
end


var_names = var_names(1:end-1);

%% 计算Dagum基尼系数
for t = 1:T
     [A{t}] = Rank_Num_plus(HH(:,t),Type,Num_of_Type); 
     
     for i = 1:Num_of_Type
         eval(['Num',num2str(i),'=','cell2mat(A{t}(i))',';']);
     end 
     
     
     % 在函数调用时，将字符串作为代码执行
     [G_Total{t},G_W{t},G_sub{t},G_nb{t},G_jh{t},G_t{t},G_test{t}] = eval(sprintf('Dagum_Gini(%s);', var_names));   
     
end

%% Dagum基尼系数集中展示

Year_1 = begin_year+T-1;

j = 0;
for i = begin_year:Year_1
      j=j+1;
      Year_Names{j} = char([num2str(i),'年']);
end

Gini_Total = cell2mat(G_Total)';
Gini_W = cell2mat(G_W)';
Gini_nb = cell2mat(G_nb)';
Gini_t = cell2mat(G_t)';

fprintf(1,'1. 总体基尼系数及各部分贡献');
Table_Ginis = table(Gini_Total,Gini_W,Gini_nb,Gini_t,'RowNames',Year_Names)


end

